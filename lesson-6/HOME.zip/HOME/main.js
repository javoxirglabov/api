const logName = document.querySelector('#name-log')
const logSurName = document.querySelector('#name-sur-log')
const form = document.querySelector('.form')
const regPanel = document.querySelector('.box')
const p = document.querySelector('#p')
const p1 = document.querySelector('#p1')
const display = document.querySelector('.display')

let newObj = { name: '', surName: '' }
form.addEventListener('submit', e => {
	e.preventDefault()

	newObj.name = logName.value
	newObj.surName = logSurName.value
	console.log(newObj)
	p.innerHTML = newObj.name
	p1.innerHTML = newObj.surName
	regPanel.classList.remove('show')
	display.innerHTML.remo
})
